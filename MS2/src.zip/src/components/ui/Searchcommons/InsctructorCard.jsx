import { Mail, MapPin } from "lucide-react";

import { AppCard } from "@/components/ui/AppCard";

function courseCode(course) {
  if (!course) return "";

  const text = String(course).trim();

  if (text.includes(" - ")) {
    return text.split(" - ")[0].trim();
  }

  const parts = text.split(/\s+/);

  if (parts.length >= 2) {
    return parts.slice(0, 2).join(" ");
  }

  return text;
}

export default function InstructorCard({ instructor, onView }) {
  const courses = Array.isArray(instructor.courses)
    ? instructor.courses
    : [];

  const visibleCourses = courses.slice(0, 3);
  const remainingCourses = Math.max(courses.length - visibleCourses.length, 0);

  return (
    <AppCard
      role="link"
      tabIndex={0}
      onClick={onView}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onView?.();
        }
      }}
      className="
        group
        cursor-pointer
        rounded-[22px]
        border border-[var(--card-border)]
        bg-[var(--card-bg)]
        p-5
        shadow-[var(--shadow-card)]
        outline-none
        transition-all duration-300
        hover:-translate-y-1
        hover:border-[var(--primary)]/40
        hover:shadow-[var(--shadow-lifted)]
        focus-visible:ring-4
        focus-visible:ring-[#7AAACE]/20
      "
    >
      <div className="flex min-w-0 items-center gap-4">
        <img
          src={instructor.image}
          alt={instructor.name}
          className="
            h-[70px] w-[70px] shrink-0 rounded-full
            border border-[var(--card-border)]
            object-cover
            shadow-[0_8px_22px_rgba(53,88,114,0.10)]
            dark:border-white/10
          "
        />

        <div className="min-w-0">
          <h2
            className="
              truncate
              text-[19px] font-black tracking-[-0.03em]
              text-[var(--ink)]
              transition
              group-hover:text-[var(--primary)]
            "
          >
            {instructor.name}
          </h2>

          <p className="mt-1 text-[12px] font-semibold text-[var(--muted)]">
            {instructor.role}
          </p>

          <p className="mt-1 text-[11.5px] font-black text-[var(--primary)]">
            {instructor.department}
          </p>
        </div>
      </div>

      <div
        className="
          mt-4 flex flex-wrap items-center gap-x-4 gap-y-2
          border-y border-[var(--border-blue)]
          py-3
          text-[10.5px] font-semibold text-[var(--muted)]
        "
      >
        <span className="inline-flex min-w-0 items-center gap-1.5">
          <Mail className="h-3.5 w-3.5 shrink-0 text-[var(--primary)]" />
          <span className="truncate">{instructor.email}</span>
        </span>

        {instructor.office ? (
          <span className="inline-flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5 shrink-0 text-[var(--primary)]" />
            {instructor.office}
          </span>
        ) : null}
      </div>

      {courses.length ? (
        <div className="mt-4">
          <div className="flex items-center justify-between gap-3">
            <p
              className="
                text-[9.5px] font-black uppercase tracking-[0.14em]
                text-[#6F8391]
                dark:text-[#8FA5B4]
              "
            >
              Teaching
            </p>

            <span className="text-[9.5px] font-black text-[var(--muted)]">
              {courses.length} {courses.length === 1 ? "course" : "courses"}
            </span>
          </div>

          <div className="mt-2.5 flex flex-wrap items-center gap-x-2.5 gap-y-1.5">
            {visibleCourses.map((course, index) => (
              <span
                key={`${course}-${index}`}
                className="
                  text-[11px] font-black
                  text-[var(--primary)]
                "
              >
                {courseCode(course)}
                {index < visibleCourses.length - 1 ? (
                  <span className="ml-2.5 text-[#B89736] dark:text-[var(--gold)]">
                    ·
                  </span>
                ) : null}
              </span>
            ))}
          </div>

          {remainingCourses > 0 ? (
            <p className="mt-2 text-[10.5px] font-black text-[var(--primary)]">
              + {remainingCourses} more {remainingCourses === 1 ? "course" : "courses"}
            </p>
          ) : null}
        </div>
      ) : null}
    </AppCard>
  );
}
