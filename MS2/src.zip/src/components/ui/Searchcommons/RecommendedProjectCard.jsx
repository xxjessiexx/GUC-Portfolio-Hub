import CourseBadge from "@/components/ui/CourseBadge";
import {
  Star,
  Users,
  GitBranch,
} from "lucide-react";
import { formatProjectRating } from "@/lib/projectRating";

export default function RecommendedProjectCard({
  project,
}) {
  const Icon = project.icon;

  return (
    <div
      className="
        border border-[var(--card-border)]
rounded-[24px]
p-5
bg-[var(--surface)]
hover:bg-[var(--surface-strong)]
shadow-[var(--shadow-soft)]
transition-all
        transition
      "
    >
      {/* TOP */}
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4 flex-1 min-w-0">

          {/* ICON */}
          <div
            className={`
              w-14 h-14
              rounded-2xl
              flex items-center justify-center
              ${project.color}
            `}
          >
            <Icon size={24} />
          </div>

          {/* TITLE */}
          <div className="min-w-0">
            <h3 className="text-[20px] font-black text-[var(--ink)] leading-tight ">
              {project.title}
            </h3>

            <p
  className="
    mt-1
    text-[15px]
    text-[var(--muted)]
    font-semibold
    whitespace-nowrap
  "
>
  {project.course}
</p>
          </div>
        </div>

        {/* BADGE */}
        <div className="px-3 py-1 rounded-full bg-[var(--surface-soft)]
text-[var(--primary)]
border border-[var(--border-blue)] text-xs font-semibold">
          Public
        </div>
      </div>

      {/* DESCRIPTION */}
      <p
  className="
    text-[15px]
    text-[var(--muted)]
    mt-4
    leading-7
    min-h-[96px]
  "
>
  {project.description}
</p>

      {/* TAGS */}
      <div className="flex flex-wrap gap-2 mt-5">
        {project.tags.map((tag) => (
          <CourseBadge
            key={tag}
            course={tag}
            className="mt-0"
          />
        ))}
      </div>

      {/* FOOTER */}
      <div
  className="
    flex items-center justify-between
    mt-6
    text-sm
    text-[var(--muted)]
    font-medium
  "
>
  <div className="flex items-center gap-1">
    <Star size={15} className="text-yellow-500" />
    {formatProjectRating(project.rating)}
  </div>

  <div className="flex items-center gap-1">
    <Users size={15} />
    <span>{project.contributors} Contributors</span>
  </div>

  <div className="flex items-center gap-1">
    <GitBranch size={15} />
    <span>{project.updated}</span>
  </div>
</div>
    </div>
  );
}