// src/components/ui/Searchcommons/PortfolioCard.jsx

import { BadgeCheck, FolderOpen } from "lucide-react";
import { useNavigate } from "react-router-dom";

import { AppCard } from "@/components/ui/AppCard";
import CourseBadge from "@/components/ui/CourseBadge";
import FavoriteButton from "./FavoriteButton";

export default function PortfolioCard({
  portfolio,
  toggleFavorite,
  showReport = false,
  onReport,
  compactBadges = false,
}) {
  const navigate = useNavigate();

  const openPortfolio = () =>
    navigate(`/public-portfolio?userId=${portfolio.id}`);

  const visibleSkills = Array.isArray(portfolio.skills)
    ? portfolio.skills
    : [];

  const isOutstanding = Number(portfolio.projects || 0) >= 6;

  return (
    <AppCard
      role="link"
      tabIndex={0}
      onClick={openPortfolio}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          openPortfolio();
        }
      }}
      className="
        group
        flex h-full cursor-pointer flex-col
        rounded-[22px]
        border border-[var(--card-border)]
        bg-[var(--card-bg)]
        p-4.5
        shadow-[var(--shadow-card)]
        outline-none
        transition-all duration-300
        hover:-translate-y-1
        hover:border-[var(--primary)]/45
        hover:shadow-[var(--shadow-lifted)]
        focus-visible:ring-4
        focus-visible:ring-[#7AAACE]/20
        sm:p-5
      "
    >
      {/* Identity */}
      <div className="flex items-start justify-between gap-3.5">
        <div className="flex min-w-0 items-center gap-4">
          <img
            src={portfolio.image}
            alt={portfolio.name}
            className="
              h-[68px] w-[68px] shrink-0 rounded-full
              border border-[var(--card-border)]
              object-cover
              shadow-[0_8px_22px_rgba(53,88,114,0.10)]
            "
          />

          <div className="min-w-0">
            <h3
              className="
                truncate
                text-[19px] font-black tracking-[-0.03em]
                text-[var(--ink)]
                transition
                group-hover:text-[var(--primary)]
              "
            >
              {portfolio.name}
            </h3>

            <p className="mt-1 text-[13px] font-semibold text-[var(--muted)]">
              {[portfolio.major, portfolio.level]
                .filter(Boolean)
                .join(" · ")}
            </p>

            <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
              <span
                className="
                  inline-flex items-center gap-1.5
                  rounded-full
                  border border-[var(--project-badge-border)]
                  bg-[var(--project-badge-bg)]
                  px-2 py-1
                  text-[10px] font-black
                  text-[var(--project-badge-text)]
                "
              >
                <FolderOpen className="h-3.5 w-3.5" />
                {portfolio.projects ?? 0} Projects
              </span>

              {isOutstanding ? (
                <span
                  className="
                    inline-flex items-center gap-1.5
                    rounded-full
                    border border-[var(--gold)]
                    bg-[rgba(230,199,123,0.10)]
                    px-2 py-1
                    text-[10px] font-black
                    text-[#B89736]
                    dark:text-[var(--gold)]
                  "
                >
                  <BadgeCheck className="h-3.5 w-3.5 fill-current" />
                  Outstanding
                </span>
              ) : null}
            </div>
          </div>
        </div>

        <div className="shrink-0">
          <FavoriteButton
            favorite={portfolio.favorite}
            onClick={() => toggleFavorite(portfolio.id)}
          />
        </div>
      </div>

      {/* Bio */}
      {portfolio.bio ? (
        <p
          className="
            mt-4 line-clamp-3
            text-[12px] font-semibold leading-5
            text-[var(--muted)]
          "
        >
          {portfolio.bio}
        </p>
      ) : null}

      {/* Skills */}
      {visibleSkills.length ? (
        <div className="mt-4 flex flex-wrap gap-1.5">
          {visibleSkills.map((skill) => (
            <CourseBadge
              key={skill}
              course={skill}
              className="mt-0"
            />
          ))}
        </div>
      ) : null}
    </AppCard>
  );
}
